INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_grove', 'grove', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_grove', 'grove', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_grove', 'grove', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('grove','grove')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('grove',0,'recruit','Runner',0,'{}','{}'),
	('grove',1,'officer','Gangster',0,'{}','{}'),
	('grove',2,'sergeant','Real G',0,'{}','{}'),
	('grove',3,'lieutenant','Sec. OG',0,'{}','{}'),
	('grove',4,'boss','OG',0,'{}','{}')
;